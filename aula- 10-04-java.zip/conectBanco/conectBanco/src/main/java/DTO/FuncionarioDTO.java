/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author Aluno
 */
public class FuncionarioDTO {
    private String nomeFuncionario, cidadeFuncionario;

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public String getCidadeFuncionario() {
        return cidadeFuncionario;
    }
    
      public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public void setCidadeFuncionario(String cidadeFuncionario) {
        this.cidadeFuncionario = cidadeFuncionario;
    }


 
    
}
