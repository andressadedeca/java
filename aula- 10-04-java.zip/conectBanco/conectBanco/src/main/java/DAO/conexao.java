/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class conexao {
     
    public Connection conectaBd(){
      Connection conn = null;
      
        try {
            String url = "jdbc:mysql://localhost/meu_banco?user=root&password=";
            conn = DriverManager.getConnection(url);
            
        } catch (SQLException erro) {
           JOptionPane.showMessageDialog(null, erro);
        }
    return conn;
    }
}
