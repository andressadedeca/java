create database meu_banco;

create table tabela(
	id int auto_increment unique,
    nome varchar(50),
    cidade varchar(50)
);

select * from tabela;
